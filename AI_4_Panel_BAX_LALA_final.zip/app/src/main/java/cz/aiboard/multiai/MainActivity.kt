package cz.aiboard.multiai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private lateinit var input: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,20,20,20) }
        val title = TextView(this).apply { text="AI MULTITASKING"; textSize=24f; gravity=Gravity.CENTER; setPadding(0,0,0,16) }
        root.addView(title)
        input = EditText(this).apply { hint="Napiš otázku pro všechny AI…"; minLines=3; gravity=Gravity.TOP }
        root.addView(input, LinearLayout.LayoutParams(-1,0,1f))
        val send = Button(this).apply { text="POŠLI VŠEM"; setOnClickListener { openSelected() } }
        root.addView(send)
        val grid = GridLayout(this).apply { columnCount=2; rowCount=2; setPadding(0,12,0,0) }
        listOf("ChatGPT","Gemini","Claude","Copilot").forEach { name ->
            val b=Button(this).apply { text=name; textSize=18f }
            b.setOnClickListener { openApp(name) }
            grid.addView(b, GridLayout.LayoutParams().apply { width=0; height=180; columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f) })
        }
        root.addView(grid)
        val note=TextView(this).apply { text="Prototyp: tlačítka zatím otevírají AI aplikace. Automatické vložení a odeslání přidáme v další verzi."; textSize=12f; setTextColor(Color.DKGRAY); setPadding(0,12,0,0) }
        root.addView(note)
        setContentView(root)
    }
    private fun openSelected() {
        if (input.text.toString().trim().isEmpty()) { Toast.makeText(this,"Nejdřív napiš otázku.",Toast.LENGTH_SHORT).show(); return }
        Toast.makeText(this,"Dotaz je připraven. Automatické rozeslání přidáme v další verzi.",Toast.LENGTH_LONG).show()
    }
    private fun openApp(name:String) {
        val pkg=when(name) {
            "ChatGPT"->"com.openai.chatgpt"; "Gemini"->"com.google.android.apps.bard"
            "Claude"->"com.anthropic.claude"; "Copilot"->"com.microsoft.copilot"
            else->null
        }
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q="+Uri.encode(name)))) }
        catch(e:Exception) { Toast.makeText(this,"Nepodařilo se otevřít $name",Toast.LENGTH_SHORT).show() }
    }
}
