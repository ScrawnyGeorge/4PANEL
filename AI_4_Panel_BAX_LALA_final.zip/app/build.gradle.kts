plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "cz.aiboard.multiai"; compileSdk = 35
    defaultConfig { applicationId = "cz.aiboard.multiai"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1" }
}
