# AI Multitasking – první prototyp
Otevři složku v Android Studiu. Tato první verze obsahuje pole pro dotaz, tlačítko POŠLI VŠEM a 4 AI dlaždice. Automatické ovládání cizích aplikací není zatím zapnuté; to je další krok.
